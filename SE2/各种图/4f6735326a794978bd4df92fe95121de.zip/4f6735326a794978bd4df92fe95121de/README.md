## 影院系统

#### Web前端

- html+js+css+bootstrap

#### 后端

- SpringBoot


### 项目目录

- /sql目录下的sql文件，是表结构和初始数据。