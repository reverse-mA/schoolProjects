package com.example.classqa.po;

import lombok.Data;

@Data
public class User {

}
